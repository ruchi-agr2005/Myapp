const fs = require('fs-extra');
const concat = require('concat');
(async function build() {
  const files = [
    './dist/testapp/runtime-es2015.js',
    './dist/testapp/polyfills-es2015.js',
    './dist/testapp/main-es2015.js',
  ]
  await fs.ensureDir('elements')
  await concat(files, 'elements/boa-footer.js');
  await fs.copyFile('./dist/testapp/styles.css', 'elements/styles.css')
  await fs.copy('./dist/testapp/assets/', 'elements/assets/' )
})()
