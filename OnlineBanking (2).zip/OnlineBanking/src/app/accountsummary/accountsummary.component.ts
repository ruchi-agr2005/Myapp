import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountsummary',
  templateUrl: './accountsummary.component.html',
  styleUrls: ['./accountsummary.component.css']
})
export class AccountsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
