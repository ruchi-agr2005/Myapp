import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imps',
  templateUrl: './imps.component.html',
  styleUrls: ['./imps.component.css']
})
export class ImpsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
