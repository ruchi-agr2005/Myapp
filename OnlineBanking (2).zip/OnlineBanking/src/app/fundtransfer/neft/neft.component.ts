import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-neft',
  templateUrl: './neft.component.html',
  styleUrls: ['./neft.component.css']
})
export class NeftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
