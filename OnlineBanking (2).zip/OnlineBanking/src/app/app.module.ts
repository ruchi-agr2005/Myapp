import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Injector, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginService } from './services/login.service';
import { AuthService } from './services/auth.service';
import { MenuService } from './services/menu.service';
import { HomeComponent } from './home/home.component';
import { TieredMenuModule} from 'primeng/tieredmenu';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { RequestsComponent } from './requests/requests.component';
import { TransactionComponent } from './transaction/transaction.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';
import { StatementComponent } from './statement/statement.component';
import { DetailedstatementComponent } from './detailedstatement/detailedstatement.component';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import {MatDialogModule} from '@angular/material/dialog';
import { OAuthModule} from 'angular-oauth2-oidc';
import { EditComponent } from './statement/edit/edit.component';
import { EditviewComponent } from './statement/editview/editview.component';
import { FooterComponent } from './footer/footer.component';
import { createCustomElement} from '@angular/elements';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import {HashLocationStrategy, LocationStrategy} from '@angular/common';
import {MatListModule} from '@angular/material/list';
import {RegisterComponent} from './register/register.component';
import {UserService} from './services/userservice';
import {EqualValidator} from "./register/matchvalidator";
import {MatSnackBarModule} from '@angular/material/snack-bar';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    RequestsComponent,
    TransactionComponent,
    ChequeComponent,
    AddressComponent,
    StatementComponent,
    DetailedstatementComponent,
    EditComponent,
    EditviewComponent,
    FooterComponent,
    RegisterComponent,
    EqualValidator,
  ],
  imports: [
    BrowserModule,
    MatSnackBarModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatListModule,
    ReactiveFormsModule,
    OAuthModule.forRoot(),
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })

  ],
  providers: [LoginService, AuthService, MenuService, {
    provide: LocationStrategy, useClass : HashLocationStrategy
  }, UserService],
  entryComponents: [EditComponent, EditviewComponent, FooterComponent],
  bootstrap: [AppComponent ] // AppComponent]
})
export class AppModule {
  constructor(private injector: Injector ) {
     const customElement =  createCustomElement(FooterComponent, {injector});
     customElements.define( 'boa-footer', customElement);
  }
  ngDoBootStrap() {

  }
}
