import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailedstatementComponent } from './detailedstatement.component';

describe('DetailedstatementComponent', () => {
  let component: DetailedstatementComponent;
  let fixture: ComponentFixture<DetailedstatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailedstatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailedstatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
