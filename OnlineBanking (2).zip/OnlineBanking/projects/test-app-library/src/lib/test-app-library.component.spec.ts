import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestAppLibraryComponent } from './test-app-library.component';

describe('TestAppLibraryComponent', () => {
  let component: TestAppLibraryComponent;
  let fixture: ComponentFixture<TestAppLibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestAppLibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestAppLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
