import { TestBed } from '@angular/core/testing';

import { TestAppLibraryService } from './test-app-library.service';

describe('TestAppLibraryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TestAppLibraryService = TestBed.get(TestAppLibraryService);
    expect(service).toBeTruthy();
  });
});
