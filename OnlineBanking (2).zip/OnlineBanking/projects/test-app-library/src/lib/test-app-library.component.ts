import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-testAppLibrary',
  template: `
    <p>
      test-app-library works!
    </p>
  `,
  styles: []
})
export class TestAppLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
