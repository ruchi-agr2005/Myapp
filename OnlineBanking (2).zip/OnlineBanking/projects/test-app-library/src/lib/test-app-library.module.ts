import { NgModule } from '@angular/core';
import { TestAppLibraryComponent } from './test-app-library.component';
import { MessageComponent } from './message/message.component';



@NgModule({
  declarations: [TestAppLibraryComponent, MessageComponent],
  imports: [
  ],
  exports: [TestAppLibraryComponent]
})
export class TestAppLibraryModule { }
