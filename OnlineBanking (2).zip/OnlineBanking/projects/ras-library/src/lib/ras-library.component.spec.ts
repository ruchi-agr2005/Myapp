import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RasLibraryComponent } from './ras-library.component';

describe('RasLibraryComponent', () => {
  let component: RasLibraryComponent;
  let fixture: ComponentFixture<RasLibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RasLibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RasLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
