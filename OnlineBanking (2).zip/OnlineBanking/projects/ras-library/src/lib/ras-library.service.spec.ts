import { TestBed } from '@angular/core/testing';

import { RasLibraryService } from './ras-library.service';

describe('RasLibraryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RasLibraryService = TestBed.get(RasLibraryService);
    expect(service).toBeTruthy();
  });
});
