import { NgModule } from '@angular/core';
import { RasLibraryComponent } from './ras-library.component';
import { MessageComponent } from './message/message.component';



@NgModule({
  declarations: [RasLibraryComponent, MessageComponent],
  imports: [
  ],
  exports: [RasLibraryComponent]
})
export class RasLibraryModule { }
