import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-rasLibrary',
  template: `
    <p>
      ras-library works!
    </p>
  `,
  styles: []
})
export class RasLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
